$(document).ready(function(){
});
var goPage = function(uri){
	if(uri != "undefined" &&  $.trim(uri)!=''){
		$("#contentPage").attr("src", uri);
	}
}

var reload = function(){
	location.reload();
}


$("#changeUserPwd").click(function(){
	var btn = $(this);
	btn.attr("data-toggle","modal");
	btn.attr("data-target","#change-pwd-modal");
	
	$("#change-pwd-modal #password").val('');
	$("#change-pwd-modal #oldPassword").val('');
	$("#change-pwd-modal #btn_submit").attr('onclick','changeUserPwd()');
});


var changeUserPwd = function(){
	var params =$("#change-pwd-modal #change-pwd-form").serialize();
	$.ajax({
        type: "post",
        url: "/chagnePwd",
        cache : false,  // 禁用缓存
        data: params,    // 传入已封装的参数
        dataType: "json",
        success: function(result) {
        	if(result.code!='0'){
        		return swaltemp("提示", result.msg);
        	}
        	$("#change-pwd-modal #btn_close").click();
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            return swaltemp("失败", this. result ? result.msg : "未知异常");
        }
    });
}