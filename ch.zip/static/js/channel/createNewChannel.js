//======================================================================
$("#btn_save_channel").click(function(){
	saveChannel();
});

var cleanform = function(){
	var form = '#saveForm';
	$(form+" #channelName").val('');
	$(form+" #channelNo").val('');
	$(form+" #linkeUrl").val('');
	$(form+" #rate").val('0');
	$(form+" #createTime").val('10');
}

var saveChannel  = function(){
	 var params =$("#saveForm").serialize();
	 $.ajax({
         type: "post",
         url: "/ch/saveChannel",
         cache : false,  // 禁用缓存
         data: params,    // 传入已封装的参数
         dataType: "json",
         success: function(result) {
         	if(result.code!='0'){
         		return swaltemp("提示", result.msg);
         	}
         	cleanform();
         	 swaltemp("提示", result.msg);
         },
         error: function(XMLHttpRequest, textStatus, errorThrown) {
             return swaltemp("操作失败", this. result ? result.msg : "未知异常");
         }
     });
}

var showEdit = function(elment,id){
	cleanform();
	getChannelUser(id);
	var btn = $(elment);
	btn.attr("data-toggle","modal");
	btn.attr("data-target","#save-chanel-modal");
	cleanform();
	var form = '#save-chanel-modal';
	$(form+" #btn_submit").attr('onclick','saveChannelUser()');
}

var getChannelUser  = function(id){
	 $.ajax({
        type: "post",
        url: "/channel/user/getChannelUserInfo",
        cache : false,  // 禁用缓存
        data: {"id":id},    // 传入已封装的参数
        dataType: "json",
        success: function(result) {
        	if(result.code!='0'){
        		return swaltemp("提示", result.msg);
        	}
        	var data = result.data;
        	var form = '#save-chanel-modal';
        	$(form+" #id").val(data.id);
        	$(form+" #userName").val(data.username);
        	$(form+" #status").select2("val", [data.status]);
        	$(form+" #password").val(data.password);
        	$(form+" #channelName").val(data.channelName);
        	$(form+" #rate").val(data.rate);
        	$(form+" #maxChannelCount").val(data.maxChannelCount);
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            return swaltemp("操作失败", this. result ? result.msg : "未知异常");
        }
    });
}
//======================================================================




var swaltemp = function(title,text){
	swal({
		
        title: title,
        text: text,
        type: 'warning',
        buttonsStyling: false,
        confirmButtonClass: 'btn btn-sm btn-light',
        background: 'rgba(0, 0, 0, 0.96)'
    })
}